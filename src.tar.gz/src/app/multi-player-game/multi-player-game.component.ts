import { Component, SystemJsNgModuleLoader, OnInit } from "@angular/core";
import * as Stomp from "stompjs";
import * as SockJS from "sockjs-client";

import { MatDialog } from "@angular/material";
import { ResponseData } from "../responseData";
import { MultiPlayerRulesComponent } from "../multi-player-rules/multi-player-rules.component";
import { MultiPlayerService } from "../multi-player.service";


import { timer } from 'rxjs/observable/timer'; // (for rxjs < 6) use 'rxjs/observable/timer'
import { take, map } from 'rxjs/operators';

@Component({
  selector: "app-multi-player-game",
  templateUrl: "./multi-player-game.component.html",
  styleUrls: ["./multi-player-game.component.css"]
})
export class MultiPlayerGameComponent implements OnInit {

  countDown;
  count;
  data: string[] = [];
  options: string[] = [];
  showConversation: boolean = false;
  ws: any;

  questions: ResponseData;

  userId: number = 100;
  userName: string;
  questionId: string;
  questionStamp: string;

  op1: string;
  op2: string;
  op3: string;
  op4: string;
  selectedAnswer: string;
  startTime: number;
  endTime: number;
  totalTime: number;

  disabled: boolean;
  message: any;
  i = 0;
  check = "123";
  //jsonData: ResponseData

  users = [
    { uId: 101, userName: "Ajay", score: 0 },
    { uId: 102, userName: "Fazeel", score: 0 },
    { uId: 103, userName: "Ajinkya", score: 0 },
    { uId: 104, userName: "Satyaki", score: 0 }
  ];

// setConnectionSocket(){
//   for(let i=0;i<this.users.length;i++){
//     if(this.users[i].uId != null){
//       this.connect();
//     }
//   }
// }


  constructor(
    public dialog: MatDialog,
    private multiPlayerService: MultiPlayerService
  ) {  }

  openDialog(): void {
    let dialogRef = this.dialog.open(MultiPlayerRulesComponent, {
      width: "350px",
      height: "350px"
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log("The dialog was closed");
    });
  }


  async matchingWithAsync(){
    this.i++;
    console.log(this.i);
      if(this.i == 4){
        await this.connect();
      }
  }
  connect() {
    //connect to stomp where stomp endpoint is exposed
    //let ws = new SockJS(http://172.23.238.179:8080/greeting);
    // let socket = new WebSocket("ws://localhost:8080/greeting");
    // this.ws = Stomp.over(socket);
   var socket = new SockJS("http://localhost:8080/greeting/100");
    //var ws = new WebSocket("ws://172.23.238.182:8080/api/v1/clock");
   this.ws = Stomp.over(socket);

    let that = this;
    this.ws.connect(
      {},

      function(frame) {
        that.ws.subscribe("/errors", function(message) {
          alert("Error " + message.body);
        });
        
        that.ws.subscribe("/topic/reply", function(message) {
          console.log(message);
         // this.multiPlayerService.seconds = 20;
          that.showGreeting(message.body);
          
        });
        that.disabled = true;
      }

      //this function is used to show alert box when disconnect socket
      // function(error) {
      //   alert("STOMP error " + error);
      // }
    );
  }

  disconnect() {
    if (this.ws != null) {
      this.ws.ws.close();
    }
    this.setConnected(false);
    console.log("Disconnected");
  }

  sendResponse() {
    console.log("Data Send ==========>");
    let dd = JSON.stringify({
      userId: "100",
      questionStamp: "dummy data",
      questionId: "11",
      selectedResponse: "any"
    });
    console.log("edelwksamdkmsdasmk==============>" + dd);
    this.ws.send("/app/message", {}, dd);
  }
  // let data = JSON.stringify({
  //   userName: this.userName,
  //   userId: this.userId,
  //   questionStamp: this.questionStamp,
  //   questionId: this.questionId
  // });
  // console.log("edelwksamdkmsdasmk==============>" + data);
  // this.ws.send("/app/message", {}, data);

  sendAnswer(answer) {
    
    this.selectedAnswer = answer;
    let ans = JSON.stringify({
      userId: "100",
      questionStamp: this.questionStamp,
      questionId: this.questionId,
      selectedResponse: this.selectedAnswer
    });
    console.log("end time =>>>>>>>>>>>>>>>>>>>>"+this.count)
    //console.log("selected data ==============>" + ans);
    this.ws.send("/app/message", {}, ans);
    //this.time();
  }

  //  time() {
  //    this.multiPlayerService.seconds = 20;
  //  }

  showGreeting(message) {
    //clearInterval(this.multiPlayerService.timer);
   
    this.showConversation = true;
   // console.log("Type of Data =====> " + typeof message);
    let rep = message
      .replace("{", "")
      .replace("}", "")
      .replace(/"/g, "");
    let quest = rep.split(",");

    for (let j = 0; j <= quest.length; j++) {
      this.data[j] = quest[j];
    }

    console.log("Hello");
    this.questionId = this.data[0].split(":")[1];
    console.log(this.questionId);
    this.questionStamp = this.data[1].split(":")[1];
    console.log(this.questionStamp);
    this.op1 = this.data[2].split(":")[1];
    this.op2 = this.data[3].split(":")[1];
    this.op3 = this.data[4].split(":")[1];
    this.op4 = this.data[5].split(":")[1];

    this.totalTime = parseInt(this.data[7].split(":")[1]);
    console.log(this.totalTime);
   // this.multiPlayerService.seconds = this.totalTime;

  this.startTimer();
    // this.i++;

    // if (this.i <= 5) {
    //   this.startTimer();
    // } else {
    //   this.complete();
    // }


    // this.data.push();
  }

  // complete() {
  //   clearInterval(this.multiPlayerService.timer);
  //   this.disconnect();
  // }



  

  startTimer() {
    // this.multiPlayerService.timer = setInterval(() => {
    //   this.multiPlayerService.seconds--;
    //   if (this.multiPlayerService.seconds < 1) {
    //     //this.sendAnswer("");
    //   }
    // });
    // let count = 10;
    this.count = 10;
    this.countDown = timer(0,1000).pipe(
      take(this.count),
      map(()=> --this.count)
    )
  //  if(this.countDown == 0){
  //       this.sendAnswer("");
  //   }
  }

  setConnected(connected) {
    this.disabled = connected;
    this.showConversation = connected;
    this.data = [];
  }

  ngOnInit() {
   // this.connect();
   this.matchingWithAsync();
    //this.setConnectionSocket();
    this.multiPlayerService.seconds= 20;
  }
}
